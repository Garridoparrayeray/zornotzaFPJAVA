package jarduera2_1;

public class Jarduera2_1_1 {
	public static void main(String[]args) {
		//Erakutsi pantailatik "Kaixo mundua!" mezua.
		System.out.println("Kaixo mundua");
	}
}
