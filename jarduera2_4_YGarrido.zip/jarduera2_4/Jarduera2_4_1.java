package jarduera2_4;

public class Jarduera2_4_1 {
//Testu honen luzera erakutsi: “Kaixo Zornotza”
	public static void main(String[]args) {
		String str;
		str = "Kaixo Zornotza";
		System.out.println("Testuaren luzeera "+ str.length()+ " da	");
	}
}
