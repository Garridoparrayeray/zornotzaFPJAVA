package jarduera2_5;

import java.util.Scanner;

public class jarduera2_5_1 {
	public static void main(String[] args) {
		//5 luzerako arraia definitu eta hitzekin bete.
		String izenak[] = new String[5];//5-ko luzeera.
		izenak[0]= "paco";
		izenak[1] = "patxi";
		izenak[2] = "anaia";
		izenak[3] = "aitona";
		izenak[4] = "Yeray";
		for(int i = 0;i< izenak.length;i++) {
			System.out.println(izenak[i]);
		}
	}
}
