package jarduera2_3;

public class Jarduera2_3_1 {
	//Programa bat idatzi lehenengo 10 zenbaki osoak idazten dituena, 0-tik hasita eta behetik gora (for eta while erabilita)
	public static void main(String[]args) {
		int i, a;
		i = 0;
		while(i <= 10) {
			System.out.println(i);
			i++;
		}
		for(a = 0; a<=10 ;a++) {
			System.out.println(a);
		}
	}
}
