package jarduera2_3;

public class Jarduera2_3_6 {
	//Programa bat idatzi 7aren biderkatze taula idazten ateratzen duena.
	public static void main(String[]args) {
		int i;
		int a;
		i=0;
		
		while(i<=10) {
			System.out.println(i * 7);
			i++;
		}
		for(a = 0;a<=10;a++) {
			System.out.println(a * 7);
		}
	}
}
