package jarduera2_3;

public class Jarduera2_3_2 {
	
	public static void main(String[]args) {
		//Programa bat idatzi lehenengo 10 zenbaki osoak idazten dituena, handienetik txikienera(for eta while erabilita).
		int i, a;
		i = 10;
		while(i <= 0) {
			System.out.println(i);
			i--;
		}
		for(a = 10; a<=0 ;a--) {
			System.out.println(a);
		}
	}

}
